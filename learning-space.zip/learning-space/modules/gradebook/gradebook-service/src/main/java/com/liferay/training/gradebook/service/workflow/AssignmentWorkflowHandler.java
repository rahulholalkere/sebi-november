package com.liferay.training.gradebook.service.workflow;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.security.permission.ResourceActions;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.workflow.BaseWorkflowHandler;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.kernel.workflow.WorkflowHandler;
import com.liferay.training.gradebook.model.Assignment;
import com.liferay.training.gradebook.service.AssignmentLocalService;

import java.io.Serializable;
import java.util.Locale;
import java.util.Map;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * For working with workflow handler with Assignment Entity
 * @author hgrahul
 */
@Component(immediate = true, service = WorkflowHandler.class)
public class AssignmentWorkflowHandler extends BaseWorkflowHandler<Assignment>{
	@Override
	public String getClassName() {
		return Assignment.class.getName();
	}
	
	@Override
	public String getType(Locale locale) {
		return resourceActions.getModelResource(locale, getClassName());
	}
	
	@Override
	public Assignment updateStatus(int status, Map<String, Serializable> workflowContext) throws PortalException {
		long currentUserId = GetterUtil.getLong((String) workflowContext.get(WorkflowConstants.CONTEXT_USER_ID));
		long resourcePrimaryKeyAssignmentId = GetterUtil.getLong(workflowContext.get(WorkflowConstants.CONTEXT_ENTRY_CLASS_PK));
		
		ServiceContext serviceContext = (ServiceContext) workflowContext.get("serviceContext");
		
		// Making A Call To Assignment Local Service Which Updates The Status For Workflow Based Assignment
		return assignmentLocalService.updateStatus(currentUserId, resourcePrimaryKeyAssignmentId, status, serviceContext);
	}
	
	/**
	 * All The References
	 */
	@Reference
	private AssignmentLocalService assignmentLocalService;
	
	@Reference
	private ResourceActions resourceActions;
}
